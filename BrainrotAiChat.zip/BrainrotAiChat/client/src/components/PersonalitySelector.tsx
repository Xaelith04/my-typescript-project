import { useState } from 'react';
import { AIPersonalityId, personalities, getRandomPersonality } from '@/lib/aiPersonalities';
import { cn } from '@/lib/utils';

type PersonalitySelectorProps = {
  currentPersonality: AIPersonalityId;
  onSelect: (personality: AIPersonalityId) => void;
};

export function PersonalitySelector({ currentPersonality, onSelect }: PersonalitySelectorProps) {
  const handleSelect = (personality: string | 'random') => {
    if (personality === 'random') {
      onSelect(getRandomPersonality());
    } else {
      onSelect(personality as AIPersonalityId);
    }
  };

  return (
    <div className="personality-selector bg-white dark:bg-gray-800 px-4 py-3 shadow-sm z-10 overflow-x-auto whitespace-nowrap">
      <div className="flex space-x-3 pb-1">
        {Object.values(personalities).map((personality) => (
          <div
            key={personality.id}
            data-personality={personality.id}
            className={cn(
              `personality-card ${personality.id}-theme cursor-pointer flex-shrink-0`,
              currentPersonality === personality.id && 'opacity-100',
              currentPersonality !== personality.id && 'opacity-80 hover:opacity-100'
            )}
            onClick={() => handleSelect(personality.id)}
          >
            <div 
              className={cn(
                "w-16 h-16 rounded-full flex items-center justify-center mb-1 mx-auto shadow-md",
                personality.id === 'toaster' && "jitter"
              )}
              style={{ background: personality.gradient }}
            >
              <span className="text-2xl">{personality.emoji}</span>
            </div>
            <p className="text-xs text-center font-heading font-medium dark:text-gray-200">{personality.name}</p>
          </div>
        ))}
        
        <div 
          data-personality="random"
          className="personality-card cursor-pointer flex-shrink-0"
          onClick={() => handleSelect('random')}
        >
          <div 
            className="w-16 h-16 rounded-full bg-gray-200 flex items-center justify-center mb-1 mx-auto shadow-md" 
            style={{ background: "linear-gradient(135deg, #607D8B, #455A64)" }}
          >
            <span className="text-2xl">🎲</span>
          </div>
          <p className="text-xs text-center font-heading font-medium dark:text-gray-200">Random</p>
        </div>
      </div>
    </div>
  );
}
