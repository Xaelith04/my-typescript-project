import { useRef, useEffect } from 'react';
import { MessageInput } from './MessageInput';
import { personalities } from '@/lib/aiPersonalities';
import { Message, Conversation } from '@/hooks/useChat';
import { formatTime } from '@/lib/utils';

type ChatContainerProps = {
  conversation: Conversation | null;
  isTyping: boolean;
  onSendMessage: (message: string) => void;
};

export function ChatContainer({ conversation, isTyping, onSendMessage }: ChatContainerProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  // Scroll to bottom whenever messages change
  useEffect(() => {
    scrollToBottom();
  }, [conversation?.messages, isTyping]);
  
  if (!conversation) {
    return (
      <div className="chat-container flex-grow overflow-hidden flex flex-col bg-white dark:bg-gray-800 shadow-inner">
        <div className="chat-history flex-grow p-4 overflow-y-auto">
          <div className="flex justify-center mb-6 mt-2">
            <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-3 max-w-xs text-center text-sm">
              <p className="dark:text-gray-200">No conversation selected.</p>
            </div>
          </div>
        </div>
        <MessageInput onSendMessage={onSendMessage} />
      </div>
    );
  }
  
  return (
    <div className="chat-container flex-grow overflow-hidden flex flex-col bg-white dark:bg-gray-800 shadow-inner">
      <div className="chat-history flex-grow p-4 overflow-y-auto" id="chat-messages">
        {conversation.messages.map((message) => (
          <MessageBubble key={message.id} message={message} currentPersonality={conversation.personality} />
        ))}
        
        {/* Typing indicator */}
        {isTyping && (
          <div className="message ai-message mb-4 flex">
            <div 
              className="w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center mr-2 text-white" 
              style={{ 
                background: personalities[conversation.personality].gradient
              }}
            >
              <span className="text-sm">{personalities[conversation.personality].emoji}</span>
            </div>
            <div 
              className="message-bubble max-w-[75%] p-3 rounded-lg rounded-tl-none bg-opacity-10 text-neutral-dark"
              style={{ 
                backgroundColor: `${personalities[conversation.personality].color}10`,
                borderLeft: `3px solid ${personalities[conversation.personality].color}`
              }}
            >
              <div className="flex space-x-1">
                <div className="w-2 h-2 rounded-full bg-gray-400 animate-pulse"></div>
                <div className="w-2 h-2 rounded-full bg-gray-400 animate-pulse" style={{animationDelay: '0.2s'}}></div>
                <div className="w-2 h-2 rounded-full bg-gray-400 animate-pulse" style={{animationDelay: '0.4s'}}></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      <MessageInput onSendMessage={onSendMessage} />
    </div>
  );
}

type MessageBubbleProps = {
  message: Message;
  currentPersonality: string;
};

function MessageBubble({ message, currentPersonality }: MessageBubbleProps) {
  const isSystem = message.text.startsWith('Welcome to Brainrot AI Chat');
  
  if (isSystem) {
    return (
      <div className="flex justify-center mb-6 mt-2">
        <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-3 max-w-xs text-center text-sm">
          <p className="dark:text-gray-200">{message.text}</p>
        </div>
      </div>
    );
  }
  
  if (message.sender === 'user') {
    return (
      <div className="message user-message mb-4 flex justify-end">
        <div className="message-bubble max-w-[75%] p-3 rounded-lg rounded-tr-none bg-primary/10 text-neutral-dark dark:text-gray-200 border-r-2 border-primary">
          <p className="text-sm">{message.text}</p>
          <span className="text-xs text-gray-500 block mt-1 text-right">{formatTime(message.timestamp)}</span>
        </div>
      </div>
    );
  }
  
  // AI message
  const personality = personalities[message.personality || currentPersonality as keyof typeof personalities];
  
  return (
    <div className="message ai-message mb-4 flex">
      <div 
        className="w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center mr-2 text-white" 
        style={{ background: personality.gradient }}
      >
        <span className="text-sm">{personality.emoji}</span>
      </div>
      <div 
        className="message-bubble max-w-[75%] p-3 rounded-lg rounded-tl-none bg-opacity-10 text-neutral-dark dark:text-gray-200"
        style={{ 
          backgroundColor: `${personality.color}10`,
          borderLeft: `3px solid ${personality.color}`
        }}
      >
        <p className="text-sm">{message.text}</p>
        <span className="text-xs text-gray-500 block mt-1">{formatTime(message.timestamp)}</span>
      </div>
    </div>
  );
}
