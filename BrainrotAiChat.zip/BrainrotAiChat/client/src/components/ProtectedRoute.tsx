import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/useAuth';

type ProtectedRouteProps = {
  component: React.ComponentType;
  adminOnly?: boolean;
};

export function ProtectedRoute({ 
  component: Component, 
  adminOnly = false 
}: ProtectedRouteProps) {
  const { isAuthenticated, isAdmin, isLoading } = useAuth();
  const [, navigate] = useLocation();
  
  useEffect(() => {
    if (!isLoading) {
      if (!isAuthenticated) {
        navigate('/login');
      } else if (adminOnly && !isAdmin) {
        navigate('/');
      }
    }
  }, [isAuthenticated, isAdmin, isLoading, navigate, adminOnly]);
  
  // Don't render anything while checking auth
  if (isLoading) {
    return <div className="flex justify-center items-center h-screen">Loading...</div>;
  }
  
  // If not authenticated or (admin access required but not admin), don't render
  if (!isAuthenticated || (adminOnly && !isAdmin)) {
    return null;
  }
  
  // Render the protected component
  return <Component />;
}