import { useTheme } from '@/hooks/useTheme';

export function QuirkyElements() {
  const { isDarkMode } = useTheme();
  
  return (
    <>
      {/* Random floating elements that add to the chaotic feel */}
      <div className="absolute top-20 right-5 animate-bounce text-3xl hidden md:block opacity-50">✨</div>
      <div className="absolute bottom-32 left-5 animate-pulse text-3xl hidden md:block opacity-30 rotate-12">🧠</div>
      
      {/* Add more quirky elements conditionally based on theme */}
      {isDarkMode && (
        <div className="absolute top-40 left-10 animate-pulse text-2xl hidden md:block opacity-30 rotate-45">🌙</div>
      )}
      
      {!isDarkMode && (
        <div className="absolute bottom-20 right-10 animate-bounce text-2xl hidden md:block opacity-30 -rotate-12">🌈</div>
      )}
    </>
  );
}
