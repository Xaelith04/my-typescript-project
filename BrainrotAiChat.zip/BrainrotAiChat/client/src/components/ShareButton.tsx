import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Conversation } from '@/hooks/useChat';
import { generateShareableText, copyToClipboard } from '@/lib/utils';
import { toast } from '@/hooks/use-toast';

type ShareButtonProps = {
  conversation: Conversation | null;
};

export function ShareButton({ conversation }: ShareButtonProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  
  // Don't show sharing option if no conversation is selected or no messages
  if (!conversation || conversation.messages.length <= 1) {
    return null;
  }

  const handleShare = async () => {
    setIsDialogOpen(true);
    setIsCopied(false);
  };

  const handleCopy = async () => {
    if (!conversation) return;
    
    const shareableText = generateShareableText(conversation);
    const success = await copyToClipboard(shareableText);
    
    if (success) {
      setIsCopied(true);
      toast({
        title: "Copied to clipboard!",
        description: "You can now paste the conversation wherever you want.",
      });
    } else {
      toast({
        title: "Failed to copy",
        description: "Please try again or copy the text manually.",
        variant: "destructive",
      });
    }
  };

  // Generate a shareable text representation of the conversation
  const shareableText = conversation ? generateShareableText(conversation) : '';

  return (
    <>
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              variant="ghost" 
              size="icon" 
              className="bg-white/20 rounded-full p-2 hover:bg-white/30 transition-colors"
              onClick={handleShare}
            >
              <i className="ri-share-line text-lg"></i>
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>Share Conversation</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Share this conversation</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4">
            <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-md max-h-[300px] overflow-y-auto whitespace-pre-wrap text-sm">
              {shareableText}
            </div>
            <DialogFooter className="flex sm:justify-between">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleCopy}
                className={isCopied ? "bg-green-600 hover:bg-green-700" : ""}
              >
                {isCopied ? 'Copied!' : 'Copy to Clipboard'}
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}