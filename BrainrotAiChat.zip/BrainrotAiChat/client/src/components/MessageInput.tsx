import { useState, FormEvent } from 'react';
import { Button } from '@/components/ui/button';

type MessageInputProps = {
  onSendMessage: (message: string) => void;
};

export function MessageInput({ onSendMessage }: MessageInputProps) {
  const [message, setMessage] = useState('');

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      onSendMessage(message.trim());
      setMessage('');
    }
  };

  return (
    <div className="message-input-area border-t border-gray-200 dark:border-gray-700 p-3 bg-white dark:bg-gray-800">
      <form onSubmit={handleSubmit} className="flex items-center space-x-2">
        <div className="flex-grow relative">
          <input 
            type="text" 
            id="message-input" 
            className="w-full px-4 py-2 rounded-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary pr-10"
            placeholder="Type your message..." 
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            autoComplete="off"
          />
          <button type="button" className="absolute right-3 top-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
            <i className="ri-emotion-line"></i>
          </button>
        </div>
        <Button 
          type="submit" 
          className="bg-primary hover:bg-primary/90 text-white p-2 rounded-full transition-colors flex-shrink-0 flex items-center justify-center w-10 h-10"
          disabled={!message.trim()}
        >
          <i className="ri-send-plane-fill"></i>
        </Button>
      </form>
    </div>
  );
}
