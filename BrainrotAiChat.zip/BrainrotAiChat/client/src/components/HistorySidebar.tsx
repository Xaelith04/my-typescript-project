import { useState } from 'react';
import { personalities } from '@/lib/aiPersonalities';
import { Conversation } from '@/hooks/useChat';
import { formatDate } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';

type HistorySidebarProps = {
  isOpen: boolean;
  onClose: () => void;
  conversations: Conversation[];
  currentConversationId: string;
  onSelectConversation: (conversationId: string) => void;
  onClearAll: () => void;
  onDeleteConversation: (conversationId: string) => void;
};

export function HistorySidebar({ 
  isOpen, 
  onClose,
  conversations,
  currentConversationId,
  onSelectConversation,
  onClearAll,
  onDeleteConversation
}: HistorySidebarProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false);

  // Sort conversations by most recent first
  const sortedConversations = [...conversations].sort(
    (a, b) => b.lastMessageTimestamp.getTime() - a.lastMessageTimestamp.getTime()
  );

  // Filter conversations by search term
  const filteredConversations = sortedConversations.filter(conv => {
    // Look for search term in any message text
    return conv.messages.some(msg => 
      msg.text.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  const getConversationPreview = (conversation: Conversation) => {
    // Find the last non-system message
    const lastMessages = conversation.messages
      .filter(msg => !msg.text.startsWith('Welcome to Brainrot AI Chat'))
      .slice(-1);
    
    if (lastMessages.length === 0) {
      return "Start a new conversation";
    }
    
    return lastMessages[0].text;
  };

  const handleClearAll = () => {
    setIsConfirmDialogOpen(false);
    onClearAll();
  };

  return (
    <>
      <div 
        className={`fixed inset-0 bg-black/50 z-20 flex justify-end transition-opacity duration-300 ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
      >
        <div 
          className={`w-full max-w-md bg-white dark:bg-gray-800 h-full overflow-auto shadow-lg flex flex-col transition-transform duration-300 ${
            isOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="p-4 bg-primary text-white flex justify-between items-center">
            <h2 className="font-heading text-lg">Chat History</h2>
            <button 
              className="text-white hover:bg-white/20 p-1 rounded"
              onClick={onClose}
            >
              <i className="ri-close-line text-xl"></i>
            </button>
          </div>
          
          <div className="p-4 border-b dark:border-gray-700">
            <div className="relative">
              <Input
                type="text"
                className="w-full pl-10 pr-4 py-2"
                placeholder="Search conversations..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <i className="ri-search-line absolute left-3 top-2.5 text-gray-400"></i>
            </div>
          </div>
          
          <div className="flex-grow overflow-auto p-2">
            {filteredConversations.length === 0 ? (
              <div className="p-4 text-center text-gray-500 dark:text-gray-400">
                {searchTerm ? 'No conversations match your search' : 'No conversations yet'}
              </div>
            ) : (
              filteredConversations.map((conversation) => (
                <div 
                  key={conversation.id}
                  className={`history-item p-3 border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer ${
                    currentConversationId === conversation.id ? 'bg-gray-100 dark:bg-gray-700' : ''
                  }`}
                  onClick={() => {
                    onSelectConversation(conversation.id);
                    onClose();
                  }}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center">
                      <span 
                        className="w-6 h-6 rounded-full flex items-center justify-center mr-2 text-xs text-white"
                        style={{ background: personalities[conversation.personality].gradient }}
                      >
                        {personalities[conversation.personality].emoji}
                      </span>
                      <span className="font-medium text-sm dark:text-gray-200">
                        {personalities[conversation.personality].name}
                      </span>
                    </div>
                    <span className="text-xs text-gray-500">
                      {formatDate(conversation.lastMessageTimestamp)}
                    </span>
                  </div>
                  <p className="text-sm text-gray-700 dark:text-gray-300 truncate">
                    {getConversationPreview(conversation)}
                  </p>
                </div>
              ))
            )}
          </div>
          
          <div className="p-4 border-t bg-gray-50 dark:bg-gray-900 dark:border-gray-700">
            <Button 
              variant="destructive" 
              className="w-full py-2 px-4 flex items-center justify-center space-x-2"
              onClick={() => setIsConfirmDialogOpen(true)}
            >
              <i className="ri-delete-bin-line mr-2"></i>
              <span>Clear All History</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Confirmation Dialog */}
      <Dialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Clear All History?</DialogTitle>
          </DialogHeader>
          <p className="py-4">
            Are you sure you want to clear all your chat history? This action cannot be undone.
          </p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsConfirmDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleClearAll}>
              Yes, Clear All
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
