import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type User = {
  username: string;
  isAdmin: boolean;
} | null;

type AuthContextType = {
  user: User;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
  isAdmin: boolean;
  isLoading: boolean;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

type AuthProviderProps = {
  children: ReactNode;
};

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Check for stored authentication on initial load
  useEffect(() => {
    const storedUser = localStorage.getItem('brainrot-user');
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (error) {
        console.error('Failed to parse stored user:', error);
        localStorage.removeItem('brainrot-user');
      }
    }
    setIsLoading(false);
  }, []);

  // Login function that requires correct username and passcode
  const login = async (username: string, password: string): Promise<boolean> => {
    // Hash of the correct passcode (not shown directly in the code)
    const correctPasscodeHash = '67e6efb8398e476c06e7f7978b3e4ca0f9ea2c70';
    
    // Simple hash function for comparison (not cryptographically secure, but fine for this demo)
    const hashPassword = (str: string) => {
      let hash = 0;
      for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash; // Convert to 32bit integer
      }
      // Convert to hex string and add some salt
      return (hash * 13579).toString(16) + 'f9ea2c70';
    };
    
    if (username.toLowerCase() === 'xaelith04' && 
        hashPassword(password) === correctPasscodeHash) {
      const newUser = {
        username: 'xaelith04',
        isAdmin: true,
      };
      
      setUser(newUser);
      localStorage.setItem('brainrot-user', JSON.stringify(newUser));
      return true;
    }
    
    // For any other credentials, login fails
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('brainrot-user');
  };

  const value = {
    user,
    login,
    logout,
    isAuthenticated: user !== null,
    isAdmin: user?.isAdmin || false,
    isLoading,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  
  return context;
}