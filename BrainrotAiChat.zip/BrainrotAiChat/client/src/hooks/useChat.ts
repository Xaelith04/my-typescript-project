import { useState, useEffect, useCallback } from 'react';
import { AIPersonalityId, getRandomResponse } from '@/lib/aiPersonalities';
import { formatTime } from '@/lib/utils';

export type Message = {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  personality?: AIPersonalityId;
};

export type Conversation = {
  id: string;
  messages: Message[];
  lastMessageTimestamp: Date;
  personality: AIPersonalityId;
};

export function useChat() {
  const [currentPersonality, setCurrentPersonality] = useState<AIPersonalityId>('wizard');
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversationId, setCurrentConversationId] = useState<string>('');
  const [isTyping, setIsTyping] = useState(false);
  
  // Load conversations from localStorage
  useEffect(() => {
    const savedConversations = localStorage.getItem('brainrot-conversations');
    if (savedConversations) {
      try {
        const parsed = JSON.parse(savedConversations);
        // Convert stored timestamps back to Date objects
        const conversationsWithDates = parsed.map((conv: any) => ({
          ...conv,
          lastMessageTimestamp: new Date(conv.lastMessageTimestamp),
          messages: conv.messages.map((msg: any) => ({
            ...msg,
            timestamp: new Date(msg.timestamp)
          }))
        }));
        setConversations(conversationsWithDates);
        
        // Set current conversation to the most recent one
        if (conversationsWithDates.length > 0) {
          const sorted = [...conversationsWithDates].sort(
            (a, b) => b.lastMessageTimestamp.getTime() - a.lastMessageTimestamp.getTime()
          );
          setCurrentConversationId(sorted[0].id);
          setCurrentPersonality(sorted[0].personality);
        } else {
          // Create a new conversation if none exists
          createNewConversation(currentPersonality);
        }
      } catch (error) {
        console.error("Error parsing saved conversations:", error);
        createNewConversation(currentPersonality);
      }
    } else {
      // Create a new conversation if none exists
      createNewConversation(currentPersonality);
    }
  }, []);
  
  // Save conversations to localStorage whenever they change
  useEffect(() => {
    if (conversations.length > 0) {
      localStorage.setItem('brainrot-conversations', JSON.stringify(conversations));
    }
  }, [conversations]);
  
  const createNewConversation = useCallback((personality: AIPersonalityId) => {
    const newId = Date.now().toString();
    const systemMessage: Message = {
      id: `system-${newId}`,
      text: `Welcome to Brainrot AI Chat! You're chatting with the ${personality.charAt(0).toUpperCase() + personality.slice(1)}. Try saying something!`,
      sender: 'ai',
      timestamp: new Date(),
      personality
    };
    
    const newConversation: Conversation = {
      id: newId,
      messages: [systemMessage],
      lastMessageTimestamp: new Date(),
      personality
    };
    
    setConversations(prev => [...prev, newConversation]);
    setCurrentConversationId(newId);
    setCurrentPersonality(personality);
    return newId;
  }, []);
  
  const changePersonality = useCallback((personality: AIPersonalityId) => {
    createNewConversation(personality);
  }, [createNewConversation]);
  
  const addMessage = useCallback((text: string, sender: 'user' | 'ai', personality?: AIPersonalityId) => {
    const now = new Date();
    const newMessage: Message = {
      id: `${sender}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      text,
      sender,
      timestamp: now,
      personality: sender === 'ai' ? personality : undefined
    };
    
    setConversations(prev => {
      return prev.map(conv => {
        if (conv.id === currentConversationId) {
          return {
            ...conv,
            messages: [...conv.messages, newMessage],
            lastMessageTimestamp: now
          };
        }
        return conv;
      });
    });
    
    return newMessage;
  }, [currentConversationId]);
  
  const sendMessage = useCallback((text: string) => {
    // Add user message
    addMessage(text, 'user');
    
    // Show AI typing indicator
    setIsTyping(true);
    
    // Simulate AI response delay (1-2 seconds)
    setTimeout(() => {
      setIsTyping(false);
      const aiResponse = getRandomResponse(currentPersonality);
      addMessage(aiResponse, 'ai', currentPersonality);
    }, Math.random() * 1000 + 1000);
  }, [addMessage, currentPersonality]);
  
  const loadConversation = useCallback((conversationId: string) => {
    const conversation = conversations.find(c => c.id === conversationId);
    if (conversation) {
      setCurrentConversationId(conversationId);
      setCurrentPersonality(conversation.personality);
    }
  }, [conversations]);
  
  const clearAllConversations = useCallback(() => {
    setConversations([]);
    localStorage.removeItem('brainrot-conversations');
    createNewConversation(currentPersonality);
  }, [createNewConversation, currentPersonality]);
  
  const deleteConversation = useCallback((conversationId: string) => {
    setConversations(prev => {
      const filtered = prev.filter(c => c.id !== conversationId);
      
      // If we're deleting the current conversation, switch to the most recent one
      if (conversationId === currentConversationId && filtered.length > 0) {
        const sorted = [...filtered].sort(
          (a, b) => b.lastMessageTimestamp.getTime() - a.lastMessageTimestamp.getTime()
        );
        setCurrentConversationId(sorted[0].id);
        setCurrentPersonality(sorted[0].personality);
      } else if (filtered.length === 0) {
        // If there are no conversations left, create a new one
        createNewConversation(currentPersonality);
      }
      
      return filtered;
    });
  }, [createNewConversation, currentConversationId, currentPersonality]);
  
  const currentConversation = conversations.find(c => c.id === currentConversationId) || null;
  
  return {
    currentPersonality,
    conversations,
    currentConversation,
    isTyping,
    changePersonality,
    sendMessage,
    loadConversation,
    clearAllConversations,
    deleteConversation
  };
}
