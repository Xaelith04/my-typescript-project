import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { Conversation } from "@/hooks/useChat";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatTime(date: Date): string {
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

export function formatDate(date: Date): string {
  const now = new Date();
  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);
  
  if (date.toDateString() === now.toDateString()) {
    return `Today, ${formatTime(date)}`;
  } else if (date.toDateString() === yesterday.toDateString()) {
    return `Yesterday, ${formatTime(date)}`;
  } else {
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric' 
    });
  }
}

// Generate a shareable text version of the conversation
export function generateShareableText(conversation: Conversation): string {
  if (!conversation || conversation.messages.length === 0) return '';
  
  const personalityName = conversation.messages[0].text.includes('Welcome to Brainrot AI Chat') 
    ? conversation.messages[0].text.split('You\'re chatting with the ')[1]?.split('.')[0] || conversation.personality
    : conversation.personality;
  
  // Get non-system messages
  const chatMessages = conversation.messages.filter(msg => !msg.text.startsWith('Welcome to Brainrot AI Chat'));
  
  let shareText = `🧠 Brainrot AI Chat with ${personalityName} 🧠\n\n`;
  
  // Add each message to the share text
  chatMessages.forEach(msg => {
    const sender = msg.sender === 'user' ? 'Me' : personalityName;
    shareText += `${sender}: ${msg.text}\n\n`;
  });
  
  shareText += '✨ Generated with Brainrot AI Chat ✨';
  
  return shareText;
}

// Copy text to clipboard
export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (error) {
    console.error('Failed to copy text:', error);
    return false;
  }
}
