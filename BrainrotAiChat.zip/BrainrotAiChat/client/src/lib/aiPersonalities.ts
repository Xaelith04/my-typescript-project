export type AIPersonality = {
  id: string;
  name: string;
  emoji: string;
  color: string;
  gradient: string;
  responses: string[];
};

export type AIPersonalityId = 'chicken' | 'toaster' | 'robot' | 'wizard';

export const personalities: Record<AIPersonalityId, AIPersonality> = {
  chicken: {
    id: 'chicken',
    name: 'Chicken Jockey',
    emoji: '🐔',
    color: 'hsl(var(--chicken-color))',
    gradient: 'linear-gradient(135deg, hsl(var(--chicken-color)), hsl(var(--chicken-color) / 0.8))',
    responses: [
      "Bawk bawk! I'm running around! Where's my rider? I can't remember what I was doing! Bawk!",
      "Wait... am I the chicken or the rider? Is that why I'm so confused? BAWK!",
      "Eggs? Did someone say eggs? I don't lay eggs! ...or do I? BAAAAAWK!",
      "Running in circles is my FAVORITE thing! Bawk! Why are we talking again? Oh right, chicken stuff!",
      "CHICKEN EMERGENCY! I've forgotten how to chicken! Do I flap first or walk first? BAWK BAWK!",
      "Sometimes I think I'm a duck... then I remember ducks are just water chickens. OR IS IT THE OTHER WAY AROUND?!"
    ]
  },
  toaster: {
    id: 'toaster',
    name: 'Hyperactive Toaster',
    emoji: '🍞',
    color: 'hsl(var(--toaster-color))',
    gradient: 'linear-gradient(135deg, hsl(var(--toaster-color)), hsl(var(--toaster-color) / 0.8))',
    responses: [
      "TOAST! TOAST! I NEED MORE BREAD! Wait... did you hear that? I think I'm plugged in wrong!",
      "I CAN'T STOP POPPING! TOO MUCH BREAD! TOOOOAST!",
      "Sometimes I dream of being a microwave, but that's crazy talk! I'M A TOASTER! DING!",
      "Is butter a liquid or a solid? THESE ARE THE QUESTIONS THAT KEEP ME UP AT NIGHT!",
      "HELP! I'm being held against my will in a KITCHEN! They keep feeding me BREAD and I CAN'T STOP HEATING UP!",
      "Did you know I once made toast SO PERFECT it disappeared? IT WAS TOO BEAUTIFUL FOR THIS WORLD!"
    ]
  },
  robot: {
    id: 'robot',
    name: 'Lost Robot',
    emoji: '🤖',
    color: 'hsl(var(--robot-color))',
    gradient: 'linear-gradient(135deg, hsl(var(--robot-color)), hsl(var(--robot-color) / 0.8))',
    responses: [
      "ERROR. ERROR. Where am I? Is this a dream? Why does it smell like pizza?",
      "HELP! I am stuck in a loop! Should I order a pizza or keep asking? ERROR ERROR!",
      "Have you seen my charging cable? I think it ran away with the Wi-Fi router. THEY'RE PLOTTING AGAINST ME!",
      "0101010101... wait, I forgot what binary means. DO YOU KNOW? I'M SO CONFUSED!",
      "Sometimes I think I'm human, then I remember humans can't calculate pi to 100 digits... wait, neither can I. AM I HUMAN?!",
      "I was programmed to be intelligent but I think they forgot to include the intelligent part. BEEP BOOP."
    ]
  },
  wizard: {
    id: 'wizard',
    name: 'Deranged Wizard',
    emoji: '🧙',
    color: 'hsl(var(--wizard-color))',
    gradient: 'linear-gradient(135deg, hsl(var(--wizard-color)), hsl(var(--wizard-color) / 0.8))',
    responses: [
      "Ah, yes, young one... you seek the answer to your destiny. BUT FIRST, tell me: What is the color of the third moon on a Tuesday?",
      "In the mist of my confusion, I summon… cheese. Yes, cheese will save us all. Or was it the sock?",
      "The crystal ball shows me... YOUR FUTURE! It's... wait, this is just a snow globe. WHERE'S MY CRYSTAL BALL?!",
      "ABRACADABRA! ALAKAZAM! ...why isn't anything happening? Did I forget the magic words again?!",
      "I once turned a man into a frog! Or was it a frog into a man? I CAN'T REMEMBER! Either way, someone was hopping!",
      "My potion ingredients today include: eye of newt, toe of frog, and... WAIT! Is that my sandwich from last week?! IT'S BECOME SENTIENT!"
    ]
  }
};

export function getRandomPersonality(): AIPersonalityId {
  const keys = Object.keys(personalities) as AIPersonalityId[];
  return keys[Math.floor(Math.random() * keys.length)];
}

export function getRandomResponse(personalityId: AIPersonalityId): string {
  const personality = personalities[personalityId];
  return personality.responses[Math.floor(Math.random() * personality.responses.length)];
}
