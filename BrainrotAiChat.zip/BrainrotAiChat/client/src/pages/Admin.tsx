import { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useLocation } from 'wouter';
import { useChat } from '@/hooks/useChat';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { personalities } from '@/lib/aiPersonalities';

export default function Admin() {
  const { isAuthenticated, isAdmin, logout } = useAuth();
  const [_, navigate] = useLocation();
  const { conversations, clearAllConversations } = useChat();
  const [visitorIps, setVisitorIps] = useState<{ip: string, time: Date}[]>([]);
  
  // In a real app, this would be fetched from server logs
  useEffect(() => {
    setVisitorIps([
      { ip: '192.168.1.105 (Current Session)', time: new Date() },
      { ip: '172.16.254.1', time: new Date(Date.now() - 15 * 60000) },
      { ip: '10.0.0.101', time: new Date(Date.now() - 43 * 60000) },
      { ip: '198.51.100.42', time: new Date(Date.now() - 112 * 60000) },
      { ip: '203.0.113.89', time: new Date(Date.now() - 256 * 60000) }
    ]);
  }, []);

  // Redirect if not authenticated or not admin
  useEffect(() => {
    if (!isAuthenticated || !isAdmin) {
      navigate('/login');
    }
  }, [isAuthenticated, isAdmin, navigate]);

  if (!isAuthenticated || !isAdmin) {
    return null; // Don't render anything while redirecting
  }

  // Count messages by personality
  const personalityStats = Object.keys(personalities).reduce((acc, id) => {
    acc[id] = 0;
    return acc;
  }, {} as Record<string, number>);

  // Calculate stats
  let totalMessages = 0;
  let totalUserMessages = 0;

  conversations.forEach(conv => {
    conv.messages.forEach(msg => {
      if (msg.sender === 'ai' && msg.personality) {
        personalityStats[msg.personality] = (personalityStats[msg.personality] || 0) + 1;
      }
      if (msg.sender === 'user') {
        totalUserMessages++;
      }
      totalMessages++;
    });
  });

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const handleClearAllData = () => {
    if (window.confirm('Are you sure you want to clear all conversation data? This cannot be undone.')) {
      clearAllConversations();
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 p-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold">Admin Dashboard</h1>
            <p className="text-gray-500 dark:text-gray-400">Welcome, Administrator</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => navigate('/')}>
              Back to Chat
            </Button>
            <Button variant="destructive" onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Total Conversations</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold">{conversations.length}</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Total Messages</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold">{totalMessages}</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">User Messages</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold">{totalUserMessages}</p>
            </CardContent>
          </Card>
        </div>

        {/* Personality Stats */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Personality Stats</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {Object.entries(personalityStats).map(([id, count]) => (
                <div 
                  key={id} 
                  className="flex items-center p-4 bg-white dark:bg-gray-800 rounded-lg shadow"
                >
                  <div 
                    className="w-10 h-10 rounded-full flex items-center justify-center mr-3"
                    style={{ background: personalities[id as keyof typeof personalities].gradient }}
                  >
                    <span>{personalities[id as keyof typeof personalities].emoji}</span>
                  </div>
                  <div>
                    <p className="font-medium">{personalities[id as keyof typeof personalities].name}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{count} messages</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        {/* Recent Visitors */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Recent Visitors (IP Addresses)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {visitorIps.map((visitor, index) => (
                <div key={index} className="flex items-center justify-between py-2 border-b last:border-0">
                  <div className="font-mono">{visitor.ip}</div>
                  <div className="text-xs text-muted-foreground">
                    {visitor.time.toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800">
          <CardHeader>
            <CardTitle className="text-red-700 dark:text-red-400">Danger Zone</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4 text-red-600 dark:text-red-400">
              The following actions are destructive and cannot be undone.
            </p>
            <Button variant="destructive" onClick={handleClearAllData}>
              Clear All Conversation Data
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}