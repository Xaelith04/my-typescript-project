import { useState } from 'react';
import { useLocation } from 'wouter';
import { PersonalitySelector } from '@/components/PersonalitySelector';
import { ChatContainer } from '@/components/ChatContainer';
import { HistorySidebar } from '@/components/HistorySidebar';
import { QuirkyElements } from '@/components/QuirkyElements';
import { ShareButton } from '@/components/ShareButton';
import { useChat } from '@/hooks/useChat';
import { useTheme } from '@/hooks/useTheme';
import { useAuth } from '@/hooks/useAuth';

export default function Home() {
  const { 
    currentPersonality, 
    conversations, 
    currentConversation,
    isTyping,
    changePersonality, 
    sendMessage,
    loadConversation,
    clearAllConversations,
    deleteConversation
  } = useChat();
  
  const { isDarkMode, toggleDarkMode } = useTheme();
  const { isAuthenticated, isAdmin } = useAuth();
  const [, navigate] = useLocation();
  const [isHistorySidebarOpen, setIsHistorySidebarOpen] = useState(false);

  return (
    <div id="app" className="flex flex-col h-screen max-w-4xl mx-auto overflow-hidden">
      {/* Header & App Title */}
      <header className="bg-primary text-white py-3 px-4 flex justify-between items-center shadow-md relative z-10">
        <div>
          <h1 className="font-accent text-xl md:text-2xl">Brainrot AI Chat</h1>
          <p className="text-xs opacity-80 font-heading">Chat with bizarre AI personalities!</p>
        </div>
        <div className="flex items-center space-x-3">
          {/* Share Button */}
          <ShareButton conversation={currentConversation} />
          
          {/* History Button */}
          <button 
            className="bg-white/20 rounded-full p-2 hover:bg-white/30 transition-colors" 
            title="View Chat History"
            onClick={() => setIsHistorySidebarOpen(true)}
          >
            <i className="ri-history-line text-lg"></i>
          </button>
          
          {/* Admin Button (shows only if logged in as admin) */}
          {isAuthenticated && isAdmin && (
            <button
              className="bg-white/20 rounded-full p-2 hover:bg-white/30 transition-colors"
              title="Admin Dashboard"
              onClick={() => navigate('/admin')}
            >
              <i className="ri-dashboard-line text-lg"></i>
            </button>
          )}
          
          {/* Login/Admin Button */}
          <button
            className="bg-white/20 rounded-full p-2 hover:bg-white/30 transition-colors"
            title={isAuthenticated ? "Logged In" : "Admin Login"}
            onClick={() => navigate('/login')}
          >
            <i className={`ri-${isAuthenticated ? 'user-fill' : 'login-circle-line'} text-lg`}></i>
          </button>
          
          {/* Theme Toggle Button */}
          <button 
            className="bg-white/20 rounded-full p-2 hover:bg-white/30 transition-colors" 
            title="Toggle Dark Mode"
            onClick={toggleDarkMode}
          >
            <i className={`ri-${isDarkMode ? 'sun' : 'moon'}-line text-lg`}></i>
          </button>
        </div>
      </header>

      {/* AI Personality Selector */}
      <PersonalitySelector 
        currentPersonality={currentPersonality}
        onSelect={changePersonality}
      />

      {/* Chat Container */}
      <ChatContainer 
        conversation={currentConversation}
        isTyping={isTyping}
        onSendMessage={sendMessage}
      />

      {/* History Sidebar */}
      <HistorySidebar 
        isOpen={isHistorySidebarOpen}
        onClose={() => setIsHistorySidebarOpen(false)}
        conversations={conversations}
        currentConversationId={currentConversation?.id || ''}
        onSelectConversation={loadConversation}
        onClearAll={clearAllConversations}
        onDeleteConversation={deleteConversation}
      />

      {/* Quirky UI Elements */}
      <QuirkyElements />
    </div>
  );
}
